// main.cpp
//
// ICS 46 Winter 2019
// Project #2: Black and White
//
// This is the program's main() function, which launches the GUI.  You will
// not want to make any changes to this file.

#include "OthelloApplication.hpp"


int main(int argc, char** argv)
{
    OthelloApplication{}.run(argc, argv);
    return 0;
}

